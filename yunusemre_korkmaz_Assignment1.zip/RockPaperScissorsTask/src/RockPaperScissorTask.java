import java.util.Random ;
import javax.swing.*;
public class RockPaperScissorTask {


    public static void main(String[] args) {
        JOptionPane.showMessageDialog(
                null,
                "The first player who reaches 5 points wins. \n                 Press OK to play!",
                "Let's start!",
                2,
                null
        );

        int userScore = 0;
        int compScore = 0;
        int uchoice;
        int CompChoice;




        String input;


        Random generate = new Random();

        for (int rnd = 1; rnd <= 50; rnd++) {
            input = JOptionPane.showInputDialog(null, "Your score:" + userScore + "  My score: " + compScore + "\nEnter rock, paper, or scissors\n" + " (rock=1 paper=2 scissors=3)", "Round: " + rnd, 3);
            uchoice = Integer.parseInt(input);

            CompChoice = generate.nextInt(3) + 1;


            while (uchoice < 1 || uchoice > 3) {
                input = JOptionPane.showInputDialog("Invalid entry ! Please Enter a 1, 2, or 3:\n 1 for rock,2 for paper and 3 for scissors  ");
                uchoice = Integer.parseInt(input);
            }
            if (uchoice == 1 && CompChoice == 1)
                JOptionPane.showMessageDialog(null, "You picked rock! " + " My pick was rock! \nTIE!");

            else if (uchoice == 2 && CompChoice == 2)
                JOptionPane.showMessageDialog(null, "You picked paper!: " + " My pick was paper! \nTIE!");

            else if (uchoice == 3 && CompChoice == 3)
                JOptionPane.showMessageDialog(null, "You picked scissors! " + " My pick was scissors! \nTIE!");

            else if (uchoice == 1 && CompChoice == 2)

                JOptionPane.showMessageDialog(null, "You picked rock! " + " My pick was paper! Paper eats rock. \nYou LOSE!");

            else if (uchoice == 1 && CompChoice == 3)

                JOptionPane.showMessageDialog(null, "You picked rock! " + " My pick was scissors! Rock crushes scissors. \nYou WIN!");

            else if (uchoice == 2 && CompChoice == 1)

                JOptionPane.showMessageDialog(null, "You picked paper! " + " My pick was rock!Paper eats rock. \nYou WIN!");

            else if (uchoice == 2 && CompChoice == 3)

                JOptionPane.showMessageDialog(null, "You picked paper! " + " My pick was scissors! Scissor cuts paper. \nYou LOSE!");

            else if (uchoice == 3 && CompChoice == 1)

                JOptionPane.showMessageDialog(null, "You picked scissors! " + " My pick was rock!Rock crushes scissors. \nYou LOSE!");

            else if (uchoice == 3 && CompChoice == 2)

                JOptionPane.showMessageDialog(null, "You picked scissors! " + " My pick was paper! Scissor cuts paper. \nYou WIN!");
            if (uchoice == 1 && CompChoice == 2)
                compScore++;
            if (uchoice == 1 && CompChoice == 3)
                userScore++;
            if (uchoice == 2 && CompChoice == 1)
                userScore++;
            if (uchoice == 2 && CompChoice == 3)
                compScore++;
            if (uchoice == 3 && CompChoice == 1)
                compScore++;
            if (uchoice == 3 && CompChoice == 2)
                userScore++;
            if (compScore == 5) {

                JOptionPane.showMessageDialog(
                        null,
                        "Bad news, YOU LOSE ! ",
                        "RESULT ",
                        0,
                        null

                );
                break;
            }
            if (userScore == 5) {

                JOptionPane.showMessageDialog(
                        null,
                        "Congrats, YOU WIN ! ",
                        "RESULT ",
                        2,
                        null
                );
                break;
            }
        }
    }
}